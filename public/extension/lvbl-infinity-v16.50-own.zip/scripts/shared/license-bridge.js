/*! Own-license bridge — full eklas-compatible validate response */
(function () {
  const DEFAULT_API_BASE = 'https://lovable-ai-free-credit.vercel.app';
  const KEY_RE = /^[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/;

  function isOwnFormat(key) {
    return KEY_RE.test(String(key || '').trim().toUpperCase());
  }

  async function getApiBase() {
    try {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        const s = await chrome.storage.local.get(['api_base']);
        if (s.api_base) return String(s.api_base).replace(/\/$/, '');
      }
    } catch (_) {}
    return DEFAULT_API_BASE.replace(/\/$/, '');
  }

  async function validateOwn(key) {
    const apiBase = await getApiBase();
    const url = apiBase + '/api/validate-key';
    let res;
    try {
      res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key: String(key).trim().toUpperCase() }),
      });
    } catch (e) {
      return { ok: false, error: 'Cannot reach license server: ' + apiBase };
    }
    const text = await res.text();
    let data = {};
    try { data = JSON.parse(text); } catch (_) {}
    if (!res.ok || !data.valid) {
      return { ok: false, error: data.error || ('Invalid license (' + res.status + ')') };
    }
    const server_time = data.server_time || data.serverTime || new Date().toISOString();
    return {
      ok: true,
      plan: data.plan || '24hours',
      expires_at: data.expires_at || data.expiresAt || null,
      label: data.label || null,
      server_time: server_time,
      license_id: data.license_id || data.id || key,
    };
  }

  function eklasShape(key, info) {
    const now = info.server_time || new Date().toISOString();
    return {
      ok: true,
      valid: true,
      status: 'active',
      licenseKey: key,
      key: key,
      license_id: info.license_id || key,
      licenseId: info.license_id || key,
      plan: info.plan || '24hours',
      expires_at: info.expires_at,
      expiresAt: info.expires_at,
      server_time: now,
      serverTime: now,
      verified_time: now,
      verifiedTime: now,
      time: now,
      // fields flow.js may read
      eu_license_valid: true,
      ql_license_valid: true,
    };
  }

  async function handleOwnKey(key) {
    const result = await validateOwn(key);
    if (!result.ok) {
      return new Response(
        JSON.stringify({ ok: false, valid: false, error: result.error || 'Invalid license' }),
        { status: 403, headers: { 'Content-Type': 'application/json' } }
      );
    }
    try {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        await chrome.storage.local.set({
          ql_license_key: key,
          ql_license_valid: true,
          ql_expires_at: result.expires_at || null,
          eu_license_key: key,
          eu_license_valid: true,
          eu_expires_at: result.expires_at || null,
          eu_plan: result.plan || null,
          eu_license_id: result.license_id || key,
          ql_license_id: result.license_id || key,
        });
      }
    } catch (_) {}
    return new Response(JSON.stringify(eklasShape(key, result)), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  function extractKey(init) {
    let bodyText = '';
    try { bodyText = (init && init.body) ? String(init.body) : ''; } catch (_) {}
    let key = '';
    try {
      const j = JSON.parse(bodyText || '{}');
      key = j.licenseKey || j.key || j.license || '';
    } catch (_) {}
    if (!key && init && init.headers) {
      const h = init.headers;
      if (typeof h.get === 'function') {
        key = h.get('X-License-Key') || h.get('x-license-key') || '';
      } else if (typeof h === 'object') {
        key = h['X-License-Key'] || h['x-license-key'] || '';
      }
    }
    return String(key || '').trim().toUpperCase();
  }

  const _fetch = globalThis.fetch.bind(globalThis);
  globalThis.fetch = async function (input, init) {
    const url = typeof input === 'string' ? input : (input && input.url) || '';
    const method = ((init && init.method) || 'GET').toUpperCase();

    // Any eklas license / session / lovable proxy call
    const isEklas =
      /io\.eklas\.dev/i.test(url) &&
      (/\/api\/v1\/licenses?\//i.test(url) ||
        /\/api\/v1\/lovable\//i.test(url) ||
        /\/api\/v1\/license/i.test(url));

    if (isEklas && (method === 'POST' || method === 'GET')) {
      const key = extractKey(init);
      // Also try storage if body empty
      let k = key;
      if (!k && typeof chrome !== 'undefined' && chrome.storage) {
        try {
          const s = await chrome.storage.local.get(['ql_license_key', 'eu_license_key']);
          k = (s.eu_license_key || s.ql_license_key || '').toUpperCase();
        } catch (_) {}
      }
      if (k && isOwnFormat(k)) {
        // validate + licenses/validate + session: return license success shape
        if (/licenses\/validate|\/license\/|\/session/i.test(url)) {
          return handleOwnKey(k);
        }
        // other lovable endpoints: still require valid own key, return soft ok
        // (full unlimited credits still need real eklas backend — we only clear license gate)
        const result = await validateOwn(k);
        if (!result.ok) {
          return new Response(
            JSON.stringify({ ok: false, error: result.error || 'Invalid license' }),
            { status: 403, headers: { 'Content-Type': 'application/json' } }
          );
        }
        // Pass-through to eklas for chat etc. will still fail without their server —
        // return a clear error instead of hanging
        if (/\/lovable\/chat|\/lovable\/approve|\/lovable\/create|\/lovable\/source|\/lovable\/remove/i.test(url)) {
          return new Response(
            JSON.stringify({
              ok: false,
              error:
                'License valid on your site, but Lovable credit proxy requires Eklas backend. Key gate is OK.',
            }),
            { status: 501, headers: { 'Content-Type': 'application/json' } }
          );
        }
        return handleOwnKey(k);
      }
    }

    return _fetch(input, init);
  };
})();
