/*! Own-license bridge: ES7N-Y7BJ-F6ZC-DCKR format via your website */
(function () {
  const API_BASE = 'https://7-c3d3.vercel.app';
  const KEY_RE = /^[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/;

  function isOwnFormat(key) {
    return KEY_RE.test(String(key || '').trim().toUpperCase());
  }

  async function validateOwn(key) {
    const res = await fetch(API_BASE + '/api/validate-key', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key: String(key).trim().toUpperCase() }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.valid) {
      return { ok: false, error: data.error || 'Invalid license' };
    }
    return {
      ok: true,
      plan: data.plan,
      expires_at: data.expires_at,
      label: data.label,
    };
  }

  function successBody(key, info) {
    return {
      ok: true,
      valid: true,
      licenseKey: key,
      key: key,
      plan: info.plan || '30days',
      expires_at: info.expires_at,
      expiresAt: info.expires_at,
      status: 'active',
    };
  }

  // Intercept fetch to eklas license validate
  const _fetch = globalThis.fetch.bind(globalThis);
  globalThis.fetch = async function (input, init) {
    const url = typeof input === 'string' ? input : (input && input.url) || '';
    const method = ((init && init.method) || 'GET').toUpperCase();

    const isLicenseCall =
      /io\.eklas\.dev\/api\/v1\/licenses\/validate/i.test(url) ||
      /io\.eklas\.dev\/api\/v1\/license/i.test(url) ||
      /io\.eklas\.dev\/api\/v1\/lovable\/session/i.test(url);

    if (isLicenseCall && method === 'POST') {
      let bodyText = '';
      try {
        bodyText = (init && init.body) ? String(init.body) : '';
      } catch (_) {}
      let key = '';
      try {
        const j = JSON.parse(bodyText || '{}');
        key = j.licenseKey || j.key || j.license || '';
      } catch (_) {}
      if (!key && init && init.headers) {
        const h = init.headers;
        if (typeof h.get === 'function') {
          key = h.get('X-License-Key') || h.get('x-license-key') || '';
        } else if (typeof h === 'object') {
          key = h['X-License-Key'] || h['x-license-key'] || '';
        }
      }
      key = String(key || '').trim().toUpperCase();

      if (isOwnFormat(key)) {
        try {
          const result = await validateOwn(key);
          if (result.ok) {
            // Persist so rest of extension thinks license is active
            try {
              if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
                chrome.storage.local.set({
                  ql_license_key: key,
                  ql_license_valid: true,
                  eu_license_key: key,
                  eu_license_valid: true,
                  eu_expires_at: result.expires_at || null,
                  eu_plan: result.plan || null,
                });
              }
            } catch (_) {}
            const payload = successBody(key, result);
            return new Response(JSON.stringify(payload), {
              status: 200,
              headers: { 'Content-Type': 'application/json' },
            });
          }
          return new Response(
            JSON.stringify({ ok: false, error: result.error || 'Invalid license' }),
            { status: 403, headers: { 'Content-Type': 'application/json' } }
          );
        } catch (e) {
          return new Response(
            JSON.stringify({ ok: false, error: e.message || 'Validation failed' }),
            { status: 500, headers: { 'Content-Type': 'application/json' } }
          );
        }
      }
      // Non-own keys: pass through to original eklas
    }

    return _fetch(input, init);
  };

  // Also expose helper for panel if it calls chrome.runtime
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    try {
      chrome.runtime.onMessage.addListener((msg, _s, sendResponse) => {
        if (msg && msg.action === 'activateOwnLicense') {
          (async () => {
            const key = String(msg.licenseKey || '').trim().toUpperCase();
            if (!isOwnFormat(key)) {
              sendResponse({ ok: false, error: 'Invalid license format' });
              return;
            }
            const result = await validateOwn(key);
            if (!result.ok) {
              sendResponse({ ok: false, error: result.error });
              return;
            }
            await chrome.storage.local.set({
              ql_license_key: key,
              ql_license_valid: true,
              eu_license_key: key,
              eu_license_valid: true,
              eu_expires_at: result.expires_at || null,
              eu_plan: result.plan || null,
            });
            sendResponse({ ok: true, plan: result.plan, expires_at: result.expires_at });
          })();
          return true;
        }
      });
    } catch (_) {}
  }
})();
